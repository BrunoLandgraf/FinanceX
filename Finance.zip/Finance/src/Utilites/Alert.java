/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilites;

/**
 *
 * @author Bruno
 */
public class Alert {

    public static void MessageWarning(String tittle, String headerText, String contentText) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.WARNING);
        alert.setTitle(tittle);
        alert.setHeaderText(headerText);
        alert.setContentText(contentText);
        alert.show();
    }

}
