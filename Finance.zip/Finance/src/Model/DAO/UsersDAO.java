/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model.DAO;

import Conecction.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Bruno
 */
public class UsersDAO {

    private Connection con = null;

    public UsersDAO() {
        con = ConnectionFactory.getConnection();
    }

    public boolean find(String User, String Password) {
        String sql = "SELECT email, password FROM users WHERE email = ? AND password = ? ";

        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean check = false;
        try {

            stmt = con.prepareStatement(sql);
            stmt.setString(1, User);
            stmt.setString(2, Password);
            rs = stmt.executeQuery();

            while (rs.next()) {
                check = true;
            }

        } catch (SQLException ex) {
            System.out.println("Erro " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return check;
    }

    public boolean findByEmail(String Email) {
        String sql = "SELECT email FROM users WHERE email = ?";

        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean check = false;
        try {

            stmt = con.prepareStatement(sql);
            stmt.setString(1, Email);
            rs = stmt.executeQuery();
            
        } catch (SQLException ex) {
            System.out.println("Erro " + ex);
        }
        return check;
    }

    public boolean save(String User, String Password, String Email, int Phone) {
        String sql = "INSERT INTO users (user, password, email, phone) VALUES (?, ?, ?, ?)";

        PreparedStatement stmt = null;
        ResultSet rs = null;
        boolean check = false;
        try {

            stmt = con.prepareStatement(sql);
            stmt.setString(1, User);
            stmt.setString(2, Password);
            stmt.setString(3, Email);
            stmt.setInt(4, Phone);
            stmt.executeUpdate();

        } catch (SQLException ex) {
            System.out.println("Erro " + ex);
        } finally {
            ConnectionFactory.closeConnection(con, stmt, rs);
        }
        return check;
    }
}
