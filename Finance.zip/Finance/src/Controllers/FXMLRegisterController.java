/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controllers;

import Model.DAO.UsersDAO;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

/**
 * FXML Controller class
 *
 * @author Bruno
 */
public class FXMLRegisterController implements Initializable {

    @FXML
    private CheckBox cBox;
    @FXML
    private PasswordField pf_Password;
    @FXML
    private PasswordField pf_ShowPassword;
    @FXML
    private TextField tx_Password;
    @FXML
    private TextField tx_ShowPassword;
    @FXML
    private TextField tx_email;
    @FXML
    private TextField tx_firstName;
    @FXML
    private TextField tx_lastName;
    @FXML
    private TextField tx_Phone;
    @FXML
    private ComboBox cb_Phone;
    @FXML
    private Button bt_Done;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        tx_Password.setVisible(false);
        tx_ShowPassword.setVisible(false);

        cBox.setOnMouseClicked((MouseEvent e) -> {
            if (cBox.isSelected()) {
                pf_Password.setVisible(false);
                pf_ShowPassword.setVisible(false);
                tx_Password.setText(pf_Password.getText());
                tx_ShowPassword.setText(pf_ShowPassword.getText());
                tx_Password.setVisible(true);
                tx_ShowPassword.setVisible(true);
            } else {
                tx_Password.setVisible(false);
                tx_ShowPassword.setVisible(false);
                pf_Password.setVisible(true);
                pf_ShowPassword.setVisible(true);
                pf_ShowPassword.setText(tx_ShowPassword.getText());
                pf_Password.setText(tx_Password.getText());
            }

        });

        bt_Done.setOnMouseClicked((MouseEvent e) -> {
            if (tx_Password.getText().equals(tx_ShowPassword.getText()) && pf_Password.getText().equals(pf_ShowPassword.getText())) {
                Done();
            } else {
                Utilites.Alert.MessageWarning("Atenção", "As senhas não são Iguais", "Verifique as senhas novamente");

            }
        });

    }

    public void Done() {
        UsersDAO udao = new UsersDAO();

        if (tx_email.getText().equals(udao.findByEmail(tx_email.getText()))) {
            Utilites.Alert.MessageWarning("Atenção", "Email já cadastrado!", "Por favor, insira outro email!");
            tx_email.requestFocus();
        } else {

            try {
                udao.save(tx_firstName.getText() + " " + tx_lastName.getText(),
                        pf_Password.getText(),
                        tx_email.getText(),
                        Integer.parseInt(cb_Phone.getAccessibleText()) + Integer.parseInt(tx_Phone.getText()));
            } catch (Exception ex) {
                Logger.getLogger(FXMLLoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }
}
