/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Controllers;

import Model.Bean.Users;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author Bruno
 */
public class FXMLMainController implements Initializable {
    
    
 
    /**
     * Initializes the controller class.
     */

    @FXML
    private Label lb_Username;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Users users = new Users();
        
        lb_Username.setText(users.getUser());
        System.out.println(users.getUser());
    }
    
    /**
     *
     * @param Username
     */
}
