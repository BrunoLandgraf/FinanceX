/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXML2.java to edit this template
 */
package Controllers;

import Loaders.Main;
import Model.DAO.UsersDAO;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Loaders.Login;
import Loaders.Register;
import Model.Bean.Users;
import Utilites.Alert;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;

/**
 *
 * @author Bruno
 */
public class FXMLLoginController implements Initializable {

    Image img2 = new Image("Views/Key.png");
    ImageView view2 = new ImageView(img2);

    Image img3 = new Image("Views/User.png");
    ImageView view3 = new ImageView(img3);

    Image img4 = new Image("Views/Lock.png");
    ImageView view4 = new ImageView(img4);

    @FXML
    private TextField tx_User;
    @FXML
    private TextField tx_Password;
    @FXML
    private Button bt_Enter;
    @FXML
    private Button bt_Register;
    @FXML
    private Label lb_User;
    @FXML
    private Label lb_Password;
    @FXML
    private Label lb_Lock;
    @FXML
    private Pane login_Pane;

    /**
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Users users = new Users();

        bt_Enter.setOnMouseClicked((MouseEvent e) -> {
            users.setUser(tx_User.getText());
            logon();

        });

        bt_Register.setOnMouseClicked((MouseEvent e) -> {
            register();
        });

        login_Pane.setOnKeyPressed((KeyEvent k) -> {
            if (k.getCode() == KeyCode.ENTER) {
                logon();
            }
        });

        lb_Password.setGraphic(view2);
        lb_User.setGraphic(view3);
        lb_Lock.setGraphic(view4);

    }

    public void close() {
        Login.getStage().close();
    }

    public void logon() {
        UsersDAO udao = new UsersDAO();
        Stage stage = (Stage) bt_Enter.getScene().getWindow();

        if (udao.find(tx_User.getText(), tx_Password.getText())) {
            Main main = new Main();
            try {
                main.start(new Stage());
            } catch (Exception ex) {
                Logger.getLogger(FXMLLoginController.class.getName()).log(Level.SEVERE, null, ex);
            }
            stage.close();
        } else {
            Alert.MessageWarning("Cuidado!", "Login Inválido", "Usuário ou Senha Inválidos!");
            tx_User.setText("");
            tx_Password.setText("");
            tx_User.requestFocus();
        }

    }

    public void register() {
        Register register = new Register();

        try {
            register.start(new Stage());
        } catch (Exception ex) {
            Logger.getLogger(FXMLLoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     *
     * @return
     */
}
